import{F as k,B as M,S as d}from"./storage.js";class p{static detectForms(){const t=document.querySelectorAll("form"),e=[];t.forEach((o,n)=>{const r=this.extractFormMetadata(o,n);r.fields.length>0&&e.push(r)});const i=this.detectImplicitForms();return e.push(...i),e}static extractFormMetadata(t,e){const i=this.extractFieldMetadata(t);return{formId:t.id||`form-${e}`,formName:t.name||`Form ${e+1}`,formAction:t.action,formMethod:t.method||"GET",fields:i,detectionTimestamp:new Date().toISOString()}}static extractFieldMetadata(t){const e=[];return t.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="reset"]), textarea, select').forEach((o,n)=>{const r=this.analyzeField(o,n);r&&!this.isBlockedField(r)&&e.push(r)}),e}static analyzeField(t,e){try{const i=this.getFieldLabel(t),o=t.getAttribute("placeholder")||"",n=t.getAttribute("name")||"",r=t.id||"",a=t.getAttribute("aria-label")||"",m=this.extractDataAttributes(t),c=t.className||"",b=t.getAttribute("type")||"text",y=`${i} ${o} ${n} ${r} ${a} ${c}`.toLowerCase(),f=this.classifyField(y,b);return{id:r||n||`field-${e}`,name:n,type:b,label:i,placeholder:o,ariaLabel:a,dataAttributes:m,classNames:c,confidenceScore:f?.85:0,suggestedField:f}}catch(i){return console.error("Error analyzing field:",i),null}}static getFieldLabel(t){if(t.id){const o=document.querySelector(`label[for="${t.id}"]`);if(o)return o.textContent||""}const e=t.closest("label");if(e)return e.textContent||"";const i=t.closest('[class*="form"], [class*="field"], [class*="group"]');return i?(i.textContent||"").substring(0,100):""}static extractDataAttributes(t){const e={};return Array.from(t.attributes).forEach(i=>{i.name.startsWith("data-")&&(e[i.name]=i.value)}),e}static classifyField(t,e){if(e==="email")return"email";if(e==="tel"||e==="telephone")return"phone";if(e==="date")return"dateOfBirth";for(const[i,o]of Object.entries(k))for(const n of o)if(n.test(t))return i;return null}static isBlockedField(t){const e=`${t.label} ${t.placeholder} ${t.name} ${t.type}`.toLowerCase();for(const i of M)if(i.test(e))return!0;return!1}static detectImplicitForms(){const t=[];return document.querySelectorAll('[class*="form"], [role="form"]').forEach((i,o)=>{if(i.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="reset"]), textarea, select').length>0&&!i.closest("form")){const r=this.extractFieldMetadata(i);r.length>0&&t.push({formId:i.id||`implicit-form-${o}`,formName:`Form ${o+1}`,formAction:"",formMethod:"POST",fields:r,detectionTimestamp:new Date().toISOString()})}}),t}static observeDOMChanges(t){const e=new MutationObserver(i=>{let o=!1;i.forEach(n=>{n.type==="childList"&&n.addedNodes.forEach(r=>{if(r.nodeType===1){const a=r;(a.tagName==="FORM"||a.tagName==="INPUT"||a.querySelector("form, input"))&&(o=!0)}})}),o&&t()});return e.observe(document.body,{childList:!0,subtree:!0,attributes:!1,characterData:!1}),e}static hasFillableForms(){return this.detectForms().length>0}static getFormForElement(t){return t.closest("form")||null}static getFormFields(t){return this.extractFieldMetadata(t)}}class h{static generateFieldMappings(t,e){const i=new Map;return t.forEach(o=>{if(o.suggestedField){const n=e[o.suggestedField];n&&n!==""&&i.set(o.id,o.suggestedField)}}),i}static fillField(t,e){try{const i=t.value;t.value=e;const o=new Event("input",{bubbles:!0});t.dispatchEvent(o);const n=new Event("change",{bubbles:!0});t.dispatchEvent(n);const r=new Event("blur",{bubbles:!0});t.dispatchEvent(r);const a=new Event("focus",{bubbles:!0});return t.dispatchEvent(a),t.value===e}catch(i){return console.error("Error filling field:",i),!1}}static fillForm(t,e,i){const o=[];return e.forEach((n,r)=>{const a=t.querySelector(`[id="${r}"], [name="${r}"]`);if(a){const m=String(i[n]||""),c=this.fillField(a,m);o.push({fieldId:r,success:c})}}),o}static findBestMatchingField(t,e){const i=t.find(n=>n.suggestedField===e);return i||t.map(n=>({field:n,score:this.calculateFieldMatchScore(n,e)})).filter(n=>n.score>.5).sort((n,r)=>r.score-n.score)[0]?.field||null}static calculateFieldMatchScore(t,e){let i=0;const o=`${t.label} ${t.placeholder} ${t.name} ${t.id}`.toLowerCase();return({fullName:["name","full name","first name","last name"],email:["email","mail","contact","inbox"],phone:["phone","tel","mobile","cell"],dateOfBirth:["date","birth","dob","age"],address:["address","street","line 1"],city:["city","town","locality"],state:["state","province","region"],country:["country","nation"],pincode:["pin","code","zip","postal"],linkedin:["linkedin","linked in","professional"],github:["github","repository","coding"],resumeUrl:["resume","cv","curriculum"],resumeText:["resume","cover"],lastUpdated:[],version:[]}[e]||[]).forEach(a=>{o.includes(a)&&(i+=.3)}),e==="email"&&t.type==="email"&&(i+=.4),e==="phone"&&t.type==="tel"&&(i+=.4),e==="dateOfBirth"&&t.type==="date"&&(i+=.4),Math.min(i,1)}static validateFillResults(t){return t.filter(i=>i.success).length/t.length>=.5}static getVisibleFields(t){return t.filter(e=>{const i=document.getElementById(e.id)||document.querySelector(`[name="${e.name}"]`);if(!i)return!1;const o=i.getBoundingClientRect(),n=window.getComputedStyle(i);return o.width>0&&o.height>0&&n.display!=="none"&&n.visibility!=="hidden"&&n.opacity!=="0"})}static shouldSkipField(t){const e=document.getElementById(t.id)||document.querySelector(`[name="${t.name}"]`);return!!(e&&e.value||e&&e.hasAttribute("readonly")||e&&e.hasAttribute("disabled"))}}class A{constructor(t={}){this.container=null,this.button=null,this.isVisible=!1,this.config={position:t.position||"bottom-right",zIndex:t.zIndex||1e4,animationDuration:t.animationDuration||300}}create(t){this.container||(this.container=document.createElement("div"),this.container.id="securefill-floating-button-container",this.container.style.cssText=`
      position: fixed;
      ${this.getPositionStyles()}
      z-index: ${this.config.zIndex};
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    `,this.button=document.createElement("button"),this.button.id="securefill-floating-button",this.button.setAttribute("aria-label","SecureFill AI - Autofill this form"),this.button.style.cssText=`
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
      border-radius: 50%;
      width: 56px;
      height: 56px;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4), 0 2px 4px rgba(0, 0, 0, 0.1);
      transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 24px;
      padding: 0;
      margin: 0;
      font-weight: 600;
      opacity: 0;
      transform: scale(0);
    `,this.button.innerHTML="✨",this.button.addEventListener("mouseenter",()=>{this.button.style.transform="scale(1.1)",this.button.style.boxShadow="0 6px 16px rgba(102, 126, 234, 0.5), 0 3px 6px rgba(0, 0, 0, 0.15)"}),this.button.addEventListener("mouseleave",()=>{this.button.style.transform="scale(1)",this.button.style.boxShadow="0 4px 12px rgba(102, 126, 234, 0.4), 0 2px 4px rgba(0, 0, 0, 0.1)"}),this.button.addEventListener("click",e=>{e.stopPropagation(),t()}),this.container.appendChild(this.button),document.body.appendChild(this.container))}show(){!this.button||this.isVisible||(this.isVisible=!0,this.button.style.opacity="1",this.button.style.transform="scale(1)")}hide(){!this.button||!this.isVisible||(this.isVisible=!1,this.button.style.opacity="0",this.button.style.transform="scale(0)")}setLoading(t){this.button&&(t?(this.button.innerHTML="⏳",this.button.disabled=!0,this.button.style.opacity="0.7"):(this.button.innerHTML="✨",this.button.disabled=!1,this.button.style.opacity="1"))}showSuccess(){if(!this.button)return;const t=this.button.innerHTML;this.button.innerHTML="✓",this.button.style.background="linear-gradient(135deg, #11998e 0%, #38ef7d 100%)",setTimeout(()=>{this.button&&(this.button.innerHTML=t,this.button.style.background="linear-gradient(135deg, #667eea 0%, #764ba2 100%)")},2e3)}showError(t){if(!this.button)return;const e=this.button.innerHTML;this.button.innerHTML="✗",this.button.style.background="linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",t&&this.showNotification(t,"error"),setTimeout(()=>{this.button&&(this.button.innerHTML=e,this.button.style.background="linear-gradient(135deg, #667eea 0%, #764ba2 100%)")},2e3)}showNotification(t,e="success"){const i=document.createElement("div");i.id="securefill-notification",i.style.cssText=`
      position: fixed;
      bottom: 80px;
      right: 20px;
      background: ${e==="success"?"#10b981":"#ef4444"};
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      z-index: ${this.config.zIndex-1};
      font-size: 14px;
      animation: slideIn 0.3s ease-out;
      max-width: 300px;
      word-wrap: break-word;
    `,i.textContent=t,document.body.appendChild(i);const o=document.createElement("style");o.textContent=`
      @keyframes slideIn {
        from {
          transform: translateY(20px);
          opacity: 0;
        }
        to {
          transform: translateY(0);
          opacity: 1;
        }
      }
    `,document.head.appendChild(o),setTimeout(()=>{i.remove(),o.remove()},3e3)}getPositionStyles(){return{"bottom-right":"bottom: 20px; right: 20px;","bottom-left":"bottom: 20px; left: 20px;","top-right":"top: 20px; right: 20px;","top-left":"top: 20px; left: 20px;"}[this.config.position]}remove(){this.container&&(this.container.remove(),this.container=null,this.button=null,this.isVisible=!1)}setPosition(t){this.config.position=t,this.container&&(this.container.style.cssText=`
        position: fixed;
        ${this.getPositionStyles()}
        z-index: ${this.config.zIndex};
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      `)}}let l=null,x=null,u=null,F=!0,g=!1,w=!1;async function E(){try{F=await d.isAutofillEnabled(),g=await d.hasConsentGiven(),w=await d.isAutofillOnLoad(),u=await d.getUserProfile(),S(),chrome.runtime.onMessage.addListener((s,t,e)=>(T(s,e),!0)),console.log("[SecureFill] Content script initialized");try{if(w&&F&&!await d.isDomainBlocked(window.location.href)){if(!g){if(!await L()){console.log("[SecureFill] Autofill-on-load cancelled by user");return}await d.setConsent(!0),g=!0}await C()}}catch(s){console.error("[SecureFill] Autofill-on-load error:",s)}}catch(s){console.error("[SecureFill] Error initializing content script:",s)}}async function C(){try{const s=p.detectForms();if(s.length===0||(u=u??await d.getUserProfile(),!u))return;let t=0;for(const e of s){const i=document.getElementById(e.formId)||e.formId.startsWith("form-")&&document.querySelectorAll("form")[parseInt(e.formId.split("-")[1])];if(!i||!(i instanceof HTMLFormElement))continue;const n=h.getVisibleFields(e.fields).filter(c=>!h.shouldSkipField(c)),r=h.generateFieldMappings(n,u),m=h.fillForm(i,r,u).filter(c=>c.success).length;t+=m;try{const c=new URL(window.location.href).hostname;await d.logAutofillAction(c,m,!0)}catch{}}t>0&&l&&(l.showSuccess(),l.showNotification(`Autofilled ${t} field${t!==1?"s":""}`))}catch(s){console.error("[SecureFill] performAutofillOnLoad error:",s)}}function S(){if(!F)return;p.detectForms().length>0&&(l||(l=new A({position:"bottom-right"}),l.create(v)),l.show()),x||(x=p.observeDOMChanges(()=>{p.hasFillableForms()&&l&&l.show()}))}async function v(){if(!(!l||!u)){if(!g){if(!await L()){l.showError("Autofill cancelled");return}await d.setConsent(!0),g=!0}l.setLoading(!0);try{const s=p.detectForms();if(s.length===0){l.showError("No forms detected");return}let t=0,e=!0;for(const i of s){const o=document.getElementById(i.formId)||i.formId.startsWith("form-")&&document.querySelectorAll("form")[parseInt(i.formId.split("-")[1])];if(!o||!(o instanceof HTMLFormElement))continue;const n=h.getVisibleFields(i.fields),r=n.filter(f=>h.shouldSkipField(f)),a=n.filter(f=>!h.shouldSkipField(f)),m=h.generateFieldMappings(a,u),c=h.fillForm(o,m,u),b=h.validateFillResults(c);b||(e=!1);const y=c.filter(f=>f.success).length;t+=y;try{const f=new URL(window.location.href).hostname;await d.logAutofillAction(f,y,b)}catch{}}e&&t>0?(l.showSuccess(),l.showNotification(`✓ Successfully filled ${t} field${t!==1?"s":""}`)):t>0?(l.showSuccess(),l.showNotification(`Filled ${t} field${t!==1?"s":""}`)):l.showError("Could not fill any fields")}catch(s){console.error("[SecureFill] Error during autofill:",s),l.showError("Error during autofill")}finally{l.setLoading(!1)}}}function L(){return new Promise(s=>{const t=document.createElement("div");t.style.cssText=`
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 100000;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto;
    `;const e=document.createElement("div");e.style.cssText=`
      background: white;
      border-radius: 12px;
      padding: 24px;
      max-width: 400px;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
      text-align: center;
    `,e.innerHTML=`
      <h2 style="margin: 0 0 16px 0; font-size: 20px; color: #1f2937;">Allow SecureFill AI to autofill?</h2>
      <p style="margin: 0 0 24px 0; color: #6b7280; font-size: 14px;">
        SecureFill will fill this form with your stored profile data. Your password and sensitive fields will never be autofilled.
      </p>
      <div style="display: flex; gap: 12px; justify-content: center;">
        <button id="securefill-deny" style="
          padding: 10px 20px;
          border: 1px solid #e5e7eb;
          border-radius: 6px;
          background: white;
          cursor: pointer;
          font-size: 14px;
          font-weight: 500;
          color: #6b7280;
          transition: all 0.2s;
        ">Don't Fill</button>
        <button id="securefill-allow" style="
          padding: 10px 20px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-size: 14px;
          font-weight: 500;
          transition: all 0.2s;
        ">Allow Autofill</button>
      </div>
    `,t.appendChild(e),document.body.appendChild(t);const i=e.querySelector("#securefill-deny"),o=e.querySelector("#securefill-allow"),n=()=>{t.remove()};i.addEventListener("click",()=>{n(),s(!1)}),o.addEventListener("click",()=>{n(),s(!0)}),t.addEventListener("click",r=>{r.target===t&&(n(),s(!1))})})}async function T(s,t){try{switch(s.type){case"FORM_DETECTED":S(),t({success:!0});break;case"REQUEST_AUTOFILL":await v(),t({success:!0});break;case"GET_PROFILE":t({profile:u});break;case"SAVE_PROFILE":s.payload&&(u=s.payload,await d.saveUserProfile(u),t({success:!0}));break;default:t({error:"Unknown message type"})}}catch(e){console.error("[SecureFill] Error handling message:",e),t({error:String(e)})}}window.addEventListener("beforeunload",()=>{x&&x.disconnect(),l&&l.remove()});document.readyState==="loading"?document.addEventListener("DOMContentLoaded",E):E();
